
  # Perfumery Website/Application

  This is a code bundle for Perfumery Website/Application. The original project is available at https://www.figma.com/design/4k2FITTwEMofLzL8M4quvu/Perfumery-Website-Application.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  