package ar.edu.huergo.lbgonzalez.fragantify;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FragantifyApplication {

	public static void main(String[] args) {
		SpringApplication.run(FragantifyApplication.class, args);
	}

}
