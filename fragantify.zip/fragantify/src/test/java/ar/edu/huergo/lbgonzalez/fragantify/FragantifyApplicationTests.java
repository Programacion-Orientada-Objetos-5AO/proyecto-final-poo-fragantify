package ar.edu.huergo.lbgonzalez.fragantify;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FragantifyApplicationTests {

	@Test
	void contextLoads() {
	}

}
